setwd("C:\\Users\\User\\Desktop\\IT24102695_Lab_6")

#01

#Random variable X has binomial distribution with n = 50 and p = 0.85

pbinom(46, 50, 0.85, lower.tail = FALSE)



#02

# X = number of customer calls received in an hour

# Random variable X has poisson distribution with lambda=12

dpois(15,12)



