setwd("C:\\Users\\User\\Desktop\\IT24102695_Lab_7")

#01
punif(25,min=0,max=40,lower.tail=TRUE)-punif(10,min=0,max=40,lower.tail=TRUE)

#02
pexp(2,rate=0.333,lower.tail=TRUE)


#03

pnorm(130,mean=100,sd=15,lower.tail=FALSE)

qnorm(0.95,mean=100,sd=15,lower.tail=TRUE)







