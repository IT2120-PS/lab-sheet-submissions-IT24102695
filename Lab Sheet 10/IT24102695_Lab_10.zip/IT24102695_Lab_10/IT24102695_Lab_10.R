setwd("C:\\Users\\User\\Desktop\\IT24102695_Lab_10")


observed <- c(120, 95, 85, 100)

chisq_test <- chisq.test(observed)
chisq_test


