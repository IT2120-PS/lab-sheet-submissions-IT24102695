setwd("C:\\Users\\User\\Desktop\\IT24102695_Lab_8")

data<-read.table("Exercise - LaptopsWeights.txt",header = TRUE)
fix(data)
attach(data)

#Q1

weights <- c(2.46, 2.45, 2.47, 2.71, 2.46, 2.05, 2.60, 2.42, 2.43, 2.53,
             2.57, 2.85, 2.70, 2.53, 2.28, 2.20, 2.57, 2.89, 2.51, 2.47,
             2.66, 2.06, 2.41, 2.65, 2.76, 2.43, 2.61, 2.57, 2.73, 2.17,
             2.67, 2.05, 1.71, 2.32, 2.23, 2.76, 2.70, 2.13, 2.75, 2.20)

population_mean <- mean(weights)
population_mean

                                   
population_var <- var(weights)
population_var

population_sd <- sqrt(population_var)
population_sd


#Q2

sample_means <- c()
sample_sd   <- c()

for (i in 1:25) {
  s <- sample(weights, size = 6, replace = TRUE)
  sample_means[i] <- mean(s)
  sample_sd[i]   <- sd(s)
}



sample_means
sample_sd

#Q3

mean_of_sample_means <- mean(sample_means)
mean_of_sample_means

sd_of_sample_means   <- sd(sample_means)
sd_of_sample_means


#True Mean = Mean of Sample Means
abs(mean_of_sample_means - population_mean) < 0.1

#SD of Sample Means = Population_SD / sqrt(Size)
abs(sd_of_sample_means - population_sd/sqrt(6)) < 0.1








