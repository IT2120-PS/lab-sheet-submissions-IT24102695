setwd("C:\\Users\\User\\Desktop\\IT24102695_Lab_9")

#Q1

#01

baking_time <- rnorm(25,mean=45,sd=2)
baking_time


#02

t.test(baking_time,mu=46,alternative ="less")






