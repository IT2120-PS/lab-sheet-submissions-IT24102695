
setwd("C:\\Users\\User\\Desktop\\IT24102695_Lab_5")


#01

Delivery_Times<-read.table("Exercise - Lab 05.txt",header=TRUE,sep = ",")
Deli
fix(Delivery_Times)
attach(Delivery_Times)


#02

names(Delivery_Times)<-c("DeliveryTime")
attach(Delivery_Times)
hist(Delivery_Times$DeliveryTime,main="Histogram for Delivery Times")

histogram<-hist(Delivery_Times$DeliveryTime,main="Histogram for Delivery Times",breaks=seq(20,70,length=9),rigth=FALSE)


#03

breaks <- round(histogram$breaks)
freq <- histogram$counts
mids <- histogram$mids

classes <- c()

for(i in 1:length(breaks)-1){
  classes[i] <- paste0("l",breaks[i],",",breaks[i+1],")")
  
}

cbind(Classes=classes,Frequency=freq)



#04

lines(mids,freq)
plot(mids,freq,type='l',main="Frequency polygon for Delivery Times",xlab="Delivery_Time",ylab = "Frequency",ylin=c(0,max(freq)))

cum.freq <- cumsum(freq)
new <- c()

for(i in 1:length(breaks)){
  if(i==1){
    new[i]=0
  }else{
    new[i]=cum.freq[i-1]
  }
}

plot(breaks,new,type = 'l',main="cumalative Frequency Polygon for Delivery Times",xlab = "Delivery Times",ylab = "cumulative Frequency",ylim = c(0,max(cum.freq)))

cbind(upper = breaks,cumFreq = new)